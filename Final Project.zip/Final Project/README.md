# YOUR PROJECT TITLE
#### Video Demo:  <https://youtu.be/i9q9h_hpOzY>
#### Description:

                          I have done a project about humanoid robots which are Asimo, Kengoro, 
                       Sophia and Atlas. These humanoid do tasks like opening doors, doing fitness, 
                       Doing speeches and rescuing people. These humanoid robots have a body shape 
                       built to resemble the human body. The design may be for functional purposes, 
                       such as interacting with human tools and environments, for experimental 
                       purposes or for other purposes. In general, humanoid robots a head, two arms, 
                       and two legs, though some forms of humanoid robots may model only part of the 
                       body. Some humanoid robots also have heads designed to replicate human facial 
                                           features such as eyes and mouths.
